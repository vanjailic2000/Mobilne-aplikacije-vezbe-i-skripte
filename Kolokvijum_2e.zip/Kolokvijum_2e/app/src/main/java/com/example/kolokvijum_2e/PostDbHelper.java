package com.example.kolokvijum_2e;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;

public class PostDbHelper
        extends SQLiteOpenHelper {


    private static final String DATABASE_NAME =
            "posts.db";

    private static final int DATABASE_VERSION =
            1;


    private static final String TABLE_POSTS =
            "posts";

    private static final String COLUMN_ID =
            "id";

    private static final String COLUMN_REMOTE_ID =
            "remote_id";

    private static final String COLUMN_USER_ID =
            "user_id";

    private static final String COLUMN_TITLE =
            "title";

    private static final String COLUMN_BODY =
            "body";

    private static final String COLUMN_LINK =
            "link";

    private static final String COLUMN_COMMENT_COUNT =
            "comment_count";


    public PostDbHelper(Context context) {

        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }


    @Override
    public void onCreate(
            SQLiteDatabase db) {

        String sql =
                "CREATE TABLE "
                        + TABLE_POSTS
                        + " ("

                        + COLUMN_ID
                        + " INTEGER PRIMARY KEY AUTOINCREMENT, "

                        + COLUMN_REMOTE_ID
                        + " INTEGER, "

                        + COLUMN_USER_ID
                        + " INTEGER, "

                        + COLUMN_TITLE
                        + " TEXT, "

                        + COLUMN_BODY
                        + " TEXT, "

                        + COLUMN_LINK
                        + " TEXT, "

                        + COLUMN_COMMENT_COUNT
                        + " INTEGER"

                        + ")";

        db.execSQL(sql);
    }


    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        db.execSQL(
                "DROP TABLE IF EXISTS "
                        + TABLE_POSTS
        );

        onCreate(db);
    }


    // =====================================================
    // SAČUVAJ PRVIH 10 POSTOVA
    // =====================================================

    public int saveFirstTenPosts(
            List<Post> posts) {

        SQLiteDatabase db =
                getWritableDatabase();


        // Da ne dupliramo stare postove.

        db.delete(
                TABLE_POSTS,
                null,
                null
        );


        int countToSave =
                Math.min(
                        10,
                        posts.size()
                );


        int saved =
                0;


        db.beginTransaction();


        try {

            for (int i = 0;
                 i < countToSave;
                 i++) {


                Post post =
                        posts.get(i);


                ContentValues values =
                        new ContentValues();


                values.put(
                        COLUMN_REMOTE_ID,
                        post.getId()
                );


                values.put(
                        COLUMN_USER_ID,
                        post.getUserId()
                );


                values.put(
                        COLUMN_TITLE,
                        post.getTitle()
                );


                values.put(
                        COLUMN_BODY,
                        post.getBody()
                );


                values.put(
                        COLUMN_LINK,
                        post.getLink()
                );


                values.put(
                        COLUMN_COMMENT_COUNT,
                        post.getCommentCount()
                );


                long result =
                        db.insert(
                                TABLE_POSTS,
                                null,
                                values
                        );


                if (result != -1) {

                    saved++;
                }
            }


            db.setTransactionSuccessful();


        } finally {

            db.endTransaction();
        }


        return saved;
    }


    // =====================================================
    // TITLE PRVOG POSTA U TABELI
    // =====================================================

    public String getFirstPostTitle() {

        SQLiteDatabase db =
                getReadableDatabase();


        Cursor cursor =
                db.rawQuery(

                        "SELECT "
                                + COLUMN_TITLE
                                + " FROM "
                                + TABLE_POSTS
                                + " ORDER BY "
                                + COLUMN_ID
                                + " ASC LIMIT 1",

                        null
                );


        String title =
                null;


        if (cursor.moveToFirst()) {

            title =
                    cursor.getString(0);
        }


        cursor.close();


        return title;
    }


    // =====================================================
    // OBRIŠI PRVI POST U TABELI
    // =====================================================

    public boolean deleteFirstPost() {

        SQLiteDatabase db =
                getWritableDatabase();


        Cursor cursor =
                db.rawQuery(

                        "SELECT "
                                + COLUMN_ID
                                + " FROM "
                                + TABLE_POSTS
                                + " ORDER BY "
                                + COLUMN_ID
                                + " ASC LIMIT 1",

                        null
                );


        if (cursor.moveToFirst()) {


            long id =
                    cursor.getLong(0);


            cursor.close();


            int deleted =
                    db.delete(

                            TABLE_POSTS,

                            COLUMN_ID + " = ?",

                            new String[]{
                                    String.valueOf(id)
                            }
                    );


            return deleted > 0;
        }


        cursor.close();

        return false;
    }


    // =====================================================
    // BROJ POSTOVA
    // =====================================================

    public int getPostCount() {

        SQLiteDatabase db =
                getReadableDatabase();


        Cursor cursor =
                db.rawQuery(

                        "SELECT COUNT(*) FROM "
                                + TABLE_POSTS,

                        null
                );


        int count =
                0;


        if (cursor.moveToFirst()) {

            count =
                    cursor.getInt(0);
        }


        cursor.close();


        return count;
    }
}