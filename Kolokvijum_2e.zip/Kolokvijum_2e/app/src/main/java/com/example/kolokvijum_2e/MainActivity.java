package com.example.kolokvijum_2e;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity
        extends AppCompatActivity
        implements SensorEventListener {


    // =====================================================
    // UI
    // =====================================================

    private TextView textViewLocation;

    private ImageButton imageButtonCamera;

    private ImageView imageViewPhoto;

    private Switch switchPosts;

    private Button buttonDelete;


    // =====================================================
    // LOKACIJA
    // =====================================================

    private LocationManager locationManager;

    private Location lastLocation;

    private boolean showContactInsteadOfLocation =
            false;


    private ActivityResultLauncher<String[]>
            locationPermissionLauncher;


    // =====================================================
    // KAMERA
    // =====================================================

    private File photoFile;

    private Uri photoUri;


    private ActivityResultLauncher<Uri>
            cameraLauncher;


    // =====================================================
    // SENZORI
    // =====================================================

    private SensorManager sensorManager;

    private Sensor accelerometer;

    private Sensor gyroscope;


    private float accX =
            0;

    private float accY =
            0;

    private float accZ =
            0;


    private float gyroX =
            0;

    private float gyroY =
            0;

    private float gyroZ =
            0;


    // =====================================================
    // BAZA
    // =====================================================

    private PostDbHelper dbHelper;


    // Prvi Switch ON:
    // Retrofit + prvih 10 postova.
    //
    // Svaki sledeći ON:
    // title prvog posta.

    private boolean firstSwitchOnDone =
            false;


    // =====================================================
    // SHARED PREFERENCES
    // =====================================================

    private SharedPreferences sharedPreferences;


    // =====================================================
    // CONTACTS
    // =====================================================

    private ActivityResultLauncher<String>
            contactsPermissionLauncher;


    // =====================================================
    // NOTIFIKACIJE
    // =====================================================

    private static final String CHANNEL_ID =
            "posts_channel";

    private static final int NOTIFICATION_ID =
            1;


    private ActivityResultLauncher<String>
            notificationPermissionLauncher;


    // =====================================================
    // LOCATION LISTENER
    // =====================================================

    private final LocationListener
            locationListener =
            new LocationListener() {


                @Override
                public void onLocationChanged(
                        Location location) {


                    lastLocation =
                            location;


                    if (!showContactInsteadOfLocation) {

                        prikaziLokaciju(
                                location
                        );
                    }
                }


                @Override
                public void onProviderEnabled(
                        String provider) {

                }


                @Override
                public void onProviderDisabled(
                        String provider) {

                }
            };


    // =====================================================
    // ON CREATE
    // =====================================================

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {


        super.onCreate(
                savedInstanceState
        );


        setContentView(
                R.layout.activity_main
        );


        // =================================================
        // UI
        // =================================================

        textViewLocation =
                findViewById(
                        R.id.textViewLocation
                );


        imageButtonCamera =
                findViewById(
                        R.id.imageButtonCamera
                );


        imageViewPhoto =
                findViewById(
                        R.id.imageViewPhoto
                );


        switchPosts =
                findViewById(
                        R.id.switchPosts
                );


        buttonDelete =
                findViewById(
                        R.id.buttonDelete
                );


        // =================================================
        // DATABASE
        // =================================================

        dbHelper =
                new PostDbHelper(
                        this
                );


        // =================================================
        // SHARED PREFERENCES
        // =================================================

        sharedPreferences =
                getSharedPreferences(

                        "KolokvijumPreferences",

                        MODE_PRIVATE
                );


        // =================================================
        // SENZORI
        // =================================================

        sensorManager =
                (SensorManager)
                        getSystemService(
                                Context.SENSOR_SERVICE
                        );


        accelerometer =
                sensorManager
                        .getDefaultSensor(
                                Sensor.TYPE_ACCELEROMETER
                        );


        gyroscope =
                sensorManager
                        .getDefaultSensor(
                                Sensor.TYPE_GYROSCOPE
                        );


        // =================================================
        // LOCATION
        // =================================================

        locationManager =
                (LocationManager)
                        getSystemService(
                                Context.LOCATION_SERVICE
                        );


        // =================================================
        // NOTIFICATION CHANNEL
        // =================================================

        kreirajNotificationChannel();


        // =================================================
        // LOCATION PERMISSION
        // =================================================

        locationPermissionLauncher =
                registerForActivityResult(

                        new ActivityResultContracts
                                .RequestMultiplePermissions(),

                        result -> {


                            boolean fine =
                                    Boolean.TRUE.equals(

                                            result.get(
                                                    Manifest.permission
                                                            .ACCESS_FINE_LOCATION
                                            )
                                    );


                            boolean coarse =
                                    Boolean.TRUE.equals(

                                            result.get(
                                                    Manifest.permission
                                                            .ACCESS_COARSE_LOCATION
                                            )
                                    );


                            if (fine || coarse) {

                                pokreniLokaciju();

                            } else {

                                textViewLocation.setText(
                                        "Lokacija: dozvola nije odobrena"
                                );
                            }
                        }
                );


        // =================================================
        // CONTACTS PERMISSION
        // =================================================

        contactsPermissionLauncher =
                registerForActivityResult(

                        new ActivityResultContracts
                                .RequestPermission(),

                        granted -> {


                            if (granted) {

                                prikaziPrviKontakt();

                            } else {

                                textViewLocation.setText(
                                        "Dozvola za kontakte nije odobrena"
                                );
                            }
                        }
                );


        // =================================================
        // NOTIFICATION PERMISSION
        // =================================================

        notificationPermissionLauncher =
                registerForActivityResult(

                        new ActivityResultContracts
                                .RequestPermission(),

                        granted -> {

                            if (!granted) {

                                Toast.makeText(
                                        MainActivity.this,

                                        "Dozvola za notifikacije nije odobrena",

                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                );


        // =================================================
        // CAMERA RESULT
        // =================================================

        cameraLauncher =
                registerForActivityResult(

                        new ActivityResultContracts
                                .TakePicture(),

                        success -> {


                            if (success
                                    && photoUri != null) {


                                // =================================
                                // PRIKAŽI NOVU SLIKU
                                // =================================

                                imageViewPhoto.setImageURI(
                                        null
                                );


                                imageViewPhoto.setImageURI(
                                        photoUri
                                );


                                // =================================
                                // TOAST SA ŽIROSKOPOM
                                // =================================

                                String gyroText =
                                        String.format(

                                                Locale.getDefault(),

                                                "Žiroskop\n"
                                                        + "X: %.2f\n"
                                                        + "Y: %.2f\n"
                                                        + "Z: %.2f",

                                                gyroX,

                                                gyroY,

                                                gyroZ
                                        );


                                Toast.makeText(
                                        MainActivity.this,

                                        gyroText,

                                        Toast.LENGTH_LONG
                                ).show();


                            } else {


                                if (photoFile != null
                                        && photoFile.exists()) {


                                    photoFile.delete();
                                }
                            }
                        }
                );


        // =================================================
        // IMAGE BUTTON - KAMERA
        // =================================================

        imageButtonCamera
                .setOnClickListener(

                        v -> {

                            pokreniKameru();
                        }
                );


        // =================================================
        // SWITCH
        // =================================================

        switchPosts
                .setOnCheckedChangeListener(

                        (buttonView, isChecked) -> {


                            // =====================================
                            // SWITCH ON
                            // =====================================

                            if (isChecked) {


                                // Ako je prethodno bio prikazan
                                // kontakt, vraćamo lokaciju.

                                showContactInsteadOfLocation =
                                        false;


                                if (lastLocation != null) {

                                    prikaziLokaciju(
                                            lastLocation
                                    );
                                }


                                // =================================
                                // PRVI PUT ON
                                // =================================

                                if (!firstSwitchOnDone) {


                                    firstSwitchOnDone =
                                            true;


                                    dobaviISacuvajPrvih10Postova();


                                } else {


                                    // =================================
                                    // SVAKI SLEDEĆI PUT ON
                                    // =================================

                                    prikaziTitlePrvogPosta();
                                }


                            } else {


                                // =====================================
                                // SWITCH OFF
                                //
                                // 1. ČUVA TEXTVIEW U "tekst"
                                // 2. PRIKAZUJE PRVI KONTAKT
                                // =====================================


                                String trenutniTekst =
                                        textViewLocation
                                                .getText()
                                                .toString();


                                sharedPreferences
                                        .edit()
                                        .putString(

                                                "tekst",

                                                trenutniTekst
                                        )
                                        .apply();


                                showContactInsteadOfLocation =
                                        true;


                                proveriKontakteIPrikaziPrvog();
                            }
                        }
                );


        // =================================================
        // BUTTON
        //
        // DELETE PRVOG POSTA
        // =================================================

        buttonDelete
                .setOnClickListener(

                        v -> {

                            obrisiPrviPost();
                        }
                );


        // =================================================
        // LOCATION
        // =================================================

        proveriDozvoluZaLokaciju();


        // =================================================
        // NOTIFICATION PERMISSION
        // =================================================

        proveriNotificationPermission();
    }


    // =====================================================
    // LOKACIJA PERMISSION
    // =====================================================

    private void proveriDozvoluZaLokaciju() {


        boolean fine =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_FINE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarse =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_COARSE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        if (fine || coarse) {


            pokreniLokaciju();


        } else {


            locationPermissionLauncher.launch(

                    new String[]{

                            Manifest.permission
                                    .ACCESS_FINE_LOCATION,

                            Manifest.permission
                                    .ACCESS_COARSE_LOCATION
                    }
            );
        }
    }


    // =====================================================
    // LOKACIJA
    // =====================================================

    private void pokreniLokaciju() {


        boolean fine =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_FINE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarse =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_COARSE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        if (!fine && !coarse) {

            return;
        }


        try {


            Location location =
                    null;


            // =================================================
            // GPS
            // =================================================

            if (fine
                    && locationManager
                    .isProviderEnabled(
                            LocationManager.GPS_PROVIDER
                    )) {


                location =
                        locationManager
                                .getLastKnownLocation(
                                        LocationManager
                                                .GPS_PROVIDER
                                );


                locationManager
                        .requestLocationUpdates(

                                LocationManager.GPS_PROVIDER,

                                1000,

                                1,

                                locationListener
                        );
            }


            // =================================================
            // NETWORK
            // =================================================

            if (locationManager
                    .isProviderEnabled(
                            LocationManager.NETWORK_PROVIDER
                    )) {


                Location networkLocation =
                        locationManager
                                .getLastKnownLocation(
                                        LocationManager
                                                .NETWORK_PROVIDER
                                );


                if (networkLocation != null) {


                    if (location == null
                            || networkLocation.getTime()
                            > location.getTime()) {


                        location =
                                networkLocation;
                    }
                }


                locationManager
                        .requestLocationUpdates(

                                LocationManager.NETWORK_PROVIDER,

                                1000,

                                1,

                                locationListener
                        );
            }


            if (location != null) {


                lastLocation =
                        location;


                if (!showContactInsteadOfLocation) {

                    prikaziLokaciju(
                            location
                    );
                }


            } else {


                textViewLocation.setText(
                        "Lokacija: čekanje GPS signala..."
                );
            }


        } catch (SecurityException e) {


            textViewLocation.setText(
                    "Greška pri pristupu lokaciji"
            );
        }
    }


    // =====================================================
    // PRIKAZ LOKACIJE
    // =====================================================

    private void prikaziLokaciju(
            Location location) {


        String tekst =
                String.format(

                        Locale.getDefault(),

                        "Geografska širina: %.6f\n"
                                + "Geografska dužina: %.6f",

                        location.getLatitude(),

                        location.getLongitude()
                );


        textViewLocation.setText(
                tekst
        );
    }


    // =====================================================
    // KAMERA
    // =====================================================

    private void pokreniKameru() {


        try {


            File imagesDirectory =
                    new File(

                            getCacheDir(),

                            "images"
                    );


            if (!imagesDirectory.exists()) {

                imagesDirectory.mkdirs();
            }


            photoFile =
                    File.createTempFile(

                            "slika_",

                            ".jpg",

                            imagesDirectory
                    );


            photoUri =
                    FileProvider.getUriForFile(

                            this,

                            getPackageName()
                                    + ".fileprovider",

                            photoFile
                    );


            cameraLauncher.launch(
                    photoUri
            );


        } catch (IOException e) {


            Toast.makeText(
                    this,

                    "Greška pri kreiranju fotografije",

                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================================
    // RETROFIT
    //
    // PRVI SWITCH ON
    // =====================================================

    private void dobaviISacuvajPrvih10Postova() {


        ApiService apiService =
                RetrofitClient
                        .getRetrofit()
                        .create(
                                ApiService.class
                        );


        Call<List<Post>> call =
                apiService.getPosts();


        call.enqueue(

                new Callback<List<Post>>() {


                    @Override
                    public void onResponse(

                            Call<List<Post>> call,

                            Response<List<Post>> response) {


                        if (response.isSuccessful()
                                && response.body() != null) {


                            int saved =
                                    dbHelper
                                            .saveFirstTenPosts(
                                                    response.body()
                                            );


                            Toast.makeText(
                                    MainActivity.this,

                                    "Sačuvano postova u bazi: "
                                            + saved,

                                    Toast.LENGTH_LONG
                            ).show();


                        } else {


                            // Ako API nije uspeo,
                            // sledeći ON opet treba da pokuša
                            // prvi GET.

                            firstSwitchOnDone =
                                    false;


                            Toast.makeText(
                                    MainActivity.this,

                                    "Greška pri dobijanju postova",

                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }


                    @Override
                    public void onFailure(

                            Call<List<Post>> call,

                            Throwable t) {


                        firstSwitchOnDone =
                                false;


                        Toast.makeText(
                                MainActivity.this,

                                "Retrofit greška: "
                                        + t.getMessage(),

                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        );
    }


    // =====================================================
    // SVAKI SLEDEĆI SWITCH ON
    // =====================================================

    private void prikaziTitlePrvogPosta() {


        String title =
                dbHelper.getFirstPostTitle();


        if (title != null) {


            Toast.makeText(
                    this,

                    "Prvi post:\n"
                            + title,

                    Toast.LENGTH_LONG
            ).show();


        } else {


            Toast.makeText(
                    this,

                    "Nema postova u bazi",

                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================================
    // BUTTON - DELETE PRVOG POSTA
    // =====================================================

    private void obrisiPrviPost() {


        boolean deleted =
                dbHelper.deleteFirstPost();


        if (!deleted) {


            Toast.makeText(
                    this,

                    "Nema postova za brisanje",

                    Toast.LENGTH_SHORT
            ).show();


            posaljiNemaPostovaNotifikaciju();


            return;
        }


        int remaining =
                dbHelper.getPostCount();


        Toast.makeText(
                this,

                "Preostalo postova: "
                        + remaining,

                Toast.LENGTH_SHORT
        ).show();


        // Kada je obrisan poslednji post.

        if (remaining == 0) {

            posaljiNemaPostovaNotifikaciju();
        }
    }


    // =====================================================
    // CONTACTS
    // =====================================================

    private void proveriKontakteIPrikaziPrvog() {


        if (ContextCompat.checkSelfPermission(

                this,

                Manifest.permission.READ_CONTACTS

        ) == PackageManager.PERMISSION_GRANTED) {


            prikaziPrviKontakt();


        } else {


            contactsPermissionLauncher.launch(
                    Manifest.permission.READ_CONTACTS
            );
        }
    }


    // =====================================================
    // PRVI KONTAKT
    // =====================================================

    private void prikaziPrviKontakt() {


        Cursor cursor =
                getContentResolver()
                        .query(

                                ContactsContract
                                        .Contacts
                                        .CONTENT_URI,

                                new String[]{

                                        ContactsContract
                                                .Contacts
                                                .DISPLAY_NAME_PRIMARY
                                },

                                null,

                                null,

                                ContactsContract
                                        .Contacts
                                        .DISPLAY_NAME_PRIMARY
                                        + " ASC"
                        );


        if (cursor == null) {


            textViewLocation.setText(
                    "Kontakti nisu dostupni"
            );


            return;
        }


        try {


            if (cursor.moveToFirst()) {


                int nameIndex =
                        cursor.getColumnIndex(

                                ContactsContract
                                        .Contacts
                                        .DISPLAY_NAME_PRIMARY
                        );


                if (nameIndex >= 0) {


                    String ime =
                            cursor.getString(
                                    nameIndex
                            );


                    textViewLocation.setText(

                            "Prvi kontakt:\n"
                                    + ime
                    );


                } else {


                    textViewLocation.setText(
                            "Ime kontakta nije pronađeno"
                    );
                }


            } else {


                textViewLocation.setText(
                        "Nema kontakata"
                );
            }


        } finally {


            cursor.close();
        }
    }


    // =====================================================
    // NOTIFICATION CHANNEL
    // =====================================================

    private void kreirajNotificationChannel() {


        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.O) {


            NotificationChannel channel =
                    new NotificationChannel(

                            CHANNEL_ID,

                            "Postovi",

                            NotificationManager
                                    .IMPORTANCE_DEFAULT
                    );


            channel.setDescription(
                    "Obaveštenja o postovima"
            );


            NotificationManager manager =
                    getSystemService(
                            NotificationManager.class
                    );


            manager.createNotificationChannel(
                    channel
            );
        }
    }


    // =====================================================
    // NOTIFICATION PERMISSION
    // =====================================================

    private void proveriNotificationPermission() {


        if (Build.VERSION.SDK_INT >= 33) {


            if (ContextCompat.checkSelfPermission(

                    this,

                    Manifest.permission
                            .POST_NOTIFICATIONS

            ) != PackageManager.PERMISSION_GRANTED) {


                notificationPermissionLauncher.launch(
                        Manifest.permission
                                .POST_NOTIFICATIONS
                );
            }
        }
    }


    // =====================================================
    // NOTIFIKACIJA
    // =====================================================

    private void posaljiNemaPostovaNotifikaciju() {


        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(

                        this,

                        CHANNEL_ID
                )
                        .setSmallIcon(
                                android.R.drawable
                                        .ic_dialog_info
                        )

                        .setContentTitle(
                                "Postovi"
                        )

                        .setContentText(
                                "Nema više postova!"
                        )

                        .setPriority(
                                NotificationCompat
                                        .PRIORITY_DEFAULT
                        )

                        .setAutoCancel(
                                true
                        );


        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(

                this,

                Manifest.permission
                        .POST_NOTIFICATIONS

        ) != PackageManager.PERMISSION_GRANTED) {


            return;
        }


        NotificationManagerCompat
                .from(this)
                .notify(

                        NOTIFICATION_ID,

                        builder.build()
                );
    }


    // =====================================================
    // SENZORI
    // =====================================================

    @Override
    public void onSensorChanged(
            SensorEvent event) {


        // =================================================
        // AKCELEROMETAR
        //
        // TEKST BUTTON-A U REALNOM VREMENU
        // =================================================

        if (event.sensor.getType()
                == Sensor.TYPE_ACCELEROMETER) {


            accX =
                    event.values[0];

            accY =
                    event.values[1];

            accZ =
                    event.values[2];


            String text =
                    String.format(

                            Locale.getDefault(),

                            "X: %.2f Y: %.2f Z: %.2f",

                            accX,

                            accY,

                            accZ
                    );


            buttonDelete.setText(
                    text
            );
        }


        // =================================================
        // ŽIROSKOP
        // =================================================

        if (event.sensor.getType()
                == Sensor.TYPE_GYROSCOPE) {


            gyroX =
                    event.values[0];

            gyroY =
                    event.values[1];

            gyroZ =
                    event.values[2];
        }
    }


    @Override
    public void onAccuracyChanged(
            Sensor sensor,
            int accuracy) {


        // Nije potrebno.
    }


    // =====================================================
    // ON RESUME
    // =====================================================

    @Override
    protected void onResume() {


        super.onResume();


        if (accelerometer != null) {


            sensorManager.registerListener(

                    this,

                    accelerometer,

                    SensorManager.SENSOR_DELAY_NORMAL
            );
        }


        if (gyroscope != null) {


            sensorManager.registerListener(

                    this,

                    gyroscope,

                    SensorManager.SENSOR_DELAY_NORMAL
            );
        }
    }


    // =====================================================
    // ON PAUSE
    // =====================================================

    @Override
    protected void onPause() {


        super.onPause();


        sensorManager.unregisterListener(
                this
        );
    }


    // =====================================================
    // ON DESTROY
    // =====================================================

    @Override
    protected void onDestroy() {


        super.onDestroy();


        if (locationManager != null) {


            try {


                locationManager.removeUpdates(
                        locationListener
                );


            } catch (SecurityException ignored) {

            }
        }


        if (dbHelper != null) {

            dbHelper.close();
        }
    }
}