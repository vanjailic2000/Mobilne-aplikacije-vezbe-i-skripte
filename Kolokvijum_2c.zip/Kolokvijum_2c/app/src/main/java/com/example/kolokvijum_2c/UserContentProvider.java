package com.example.kolokvijum_2c;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

public class UserContentProvider
        extends ContentProvider {


    private static final int USERS =
            1;


    private static final UriMatcher
            uriMatcher;


    static {

        uriMatcher =
                new UriMatcher(
                        UriMatcher.NO_MATCH
                );


        uriMatcher.addURI(
                UserContract.AUTHORITY,
                "users",
                USERS
        );
    }


    private UserDbHelper dbHelper;


    @Override
    public boolean onCreate() {

        dbHelper =
                new UserDbHelper(
                        getContext()
                );

        return true;
    }


    // =====================================================
    // QUERY
    // =====================================================

    @Override
    public Cursor query(
            Uri uri,
            String[] projection,
            String selection,
            String[] selectionArgs,
            String sortOrder) {


        if (uriMatcher.match(uri) != USERS) {

            throw new IllegalArgumentException(
                    "Nepoznat URI: " + uri
            );
        }


        SQLiteDatabase db =
                dbHelper.getReadableDatabase();


        Cursor cursor =
                db.query(

                        UserContract.UserEntry.TABLE_NAME,

                        projection,

                        selection,

                        selectionArgs,

                        null,

                        null,

                        sortOrder
                );


        if (getContext() != null) {

            cursor.setNotificationUri(
                    getContext()
                            .getContentResolver(),

                    uri
            );
        }


        return cursor;
    }


    // =====================================================
    // INSERT
    // =====================================================

    @Override
    public Uri insert(
            Uri uri,
            ContentValues values) {


        if (uriMatcher.match(uri) != USERS) {

            throw new IllegalArgumentException(
                    "Nepoznat URI: " + uri
            );
        }


        SQLiteDatabase db =
                dbHelper.getWritableDatabase();


        long id =
                db.insert(

                        UserContract.UserEntry.TABLE_NAME,

                        null,

                        values
                );


        if (id == -1) {

            return null;
        }


        if (getContext() != null) {

            getContext()
                    .getContentResolver()
                    .notifyChange(
                            uri,
                            null
                    );
        }


        return ContentUris.withAppendedId(
                uri,
                id
        );
    }


    // =====================================================
    // BULK INSERT
    //
    // OVDE ČUVAMO SVE KORISNIKE ODJEDNOM
    // =====================================================

    @Override
    public int bulkInsert(
            Uri uri,
            ContentValues[] values) {


        if (uriMatcher.match(uri) != USERS) {

            throw new IllegalArgumentException(
                    "Nepoznat URI: " + uri
            );
        }


        SQLiteDatabase db =
                dbHelper.getWritableDatabase();


        int insertedCount =
                0;


        db.beginTransaction();


        try {

            for (ContentValues value : values) {

                long id =
                        db.insert(

                                UserContract.UserEntry.TABLE_NAME,

                                null,

                                value
                        );


                if (id != -1) {

                    insertedCount++;
                }
            }


            db.setTransactionSuccessful();


        } finally {

            db.endTransaction();
        }


        if (insertedCount > 0
                && getContext() != null) {

            getContext()
                    .getContentResolver()
                    .notifyChange(
                            uri,
                            null
                    );
        }


        return insertedCount;
    }


    // =====================================================
    // DELETE
    // =====================================================

    @Override
    public int delete(
            Uri uri,
            String selection,
            String[] selectionArgs) {


        if (uriMatcher.match(uri) != USERS) {

            throw new IllegalArgumentException(
                    "Nepoznat URI: " + uri
            );
        }


        SQLiteDatabase db =
                dbHelper.getWritableDatabase();


        int deleted =
                db.delete(

                        UserContract.UserEntry.TABLE_NAME,

                        selection,

                        selectionArgs
                );


        if (deleted > 0
                && getContext() != null) {

            getContext()
                    .getContentResolver()
                    .notifyChange(
                            uri,
                            null
                    );
        }


        return deleted;
    }


    // =====================================================
    // UPDATE
    // =====================================================

    @Override
    public int update(
            Uri uri,
            ContentValues values,
            String selection,
            String[] selectionArgs) {


        if (uriMatcher.match(uri) != USERS) {

            throw new IllegalArgumentException(
                    "Nepoznat URI: " + uri
            );
        }


        SQLiteDatabase db =
                dbHelper.getWritableDatabase();


        int updated =
                db.update(

                        UserContract.UserEntry.TABLE_NAME,

                        values,

                        selection,

                        selectionArgs
                );


        if (updated > 0
                && getContext() != null) {

            getContext()
                    .getContentResolver()
                    .notifyChange(
                            uri,
                            null
                    );
        }


        return updated;
    }


    // =====================================================
    // MIME TYPE
    // =====================================================

    @Override
    public String getType(
            Uri uri) {


        if (uriMatcher.match(uri) == USERS) {

            return "vnd.android.cursor.dir/vnd."
                    + UserContract.AUTHORITY
                    + ".users";
        }


        return null;
    }
}