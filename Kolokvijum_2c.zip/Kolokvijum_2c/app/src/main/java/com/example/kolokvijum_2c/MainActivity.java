package com.example.kolokvijum_2c;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity
        extends AppCompatActivity
        implements SensorEventListener {


    // =====================================================
    // UI
    // =====================================================

    private CheckBox checkBoxUsers;
    private CheckBox checkBoxTenthUser;

    private Button buttonSnimi;
    private Button buttonSacuvaj;

    private TextView textViewAccelerometer;
    private TextView textViewSecond;


    // =====================================================
    // AUDIO
    // =====================================================

    private MediaRecorder mediaRecorder;

    private File audioFile;

    private boolean isRecording =
            false;


    private ActivityResultLauncher<String>
            microphonePermissionLauncher;


    // =====================================================
    // SENZORI
    // =====================================================

    private SensorManager sensorManager;

    private Sensor accelerometer;
    private Sensor proximitySensor;


    private float accX = 0;
    private float accY = 0;
    private float accZ = 0;


    private float lastProximity = 0;


    // Prag smo proizvoljno odredili.
    //
    // Proximity > 0.5 = daleko
    // Proximity <= 0.5 = blizu

    private static final float
            PROXIMITY_THRESHOLD = 0.5f;


    // Pamti da li smo prethodno bili "daleko",
    // da Toast ne iskače stalno.

    private Boolean previouslyFar =
            null;


    // =====================================================
    // ON CREATE
    // =====================================================

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {

        super.onCreate(
                savedInstanceState
        );


        setContentView(
                R.layout.activity_main
        );


        // =================================================
        // UI
        // =================================================

        checkBoxUsers =
                findViewById(
                        R.id.checkBoxUsers
                );


        checkBoxTenthUser =
                findViewById(
                        R.id.checkBoxTenthUser
                );


        buttonSnimi =
                findViewById(
                        R.id.buttonSnimi
                );


        buttonSacuvaj =
                findViewById(
                        R.id.buttonSacuvaj
                );


        textViewAccelerometer =
                findViewById(
                        R.id.textViewAccelerometer
                );


        textViewSecond =
                findViewById(
                        R.id.textViewSecond
                );


        // Na početku nema šta da se zaustavlja.

        buttonSacuvaj.setEnabled(false);


        // =================================================
        // SENSOR MANAGER
        // =================================================

        sensorManager =
                (SensorManager)
                        getSystemService(
                                Context.SENSOR_SERVICE
                        );


        accelerometer =
                sensorManager.getDefaultSensor(
                        Sensor.TYPE_ACCELEROMETER
                );


        proximitySensor =
                sensorManager.getDefaultSensor(
                        Sensor.TYPE_PROXIMITY
                );


        if (accelerometer == null) {

            textViewAccelerometer.setText(
                    "Akcelerometar nije dostupan"
            );
        }


        if (proximitySensor == null) {

            textViewSecond.setText(
                    "Proximity senzor nije dostupan"
            );
        }


        // =================================================
        // MICROPHONE PERMISSION
        // =================================================

        microphonePermissionLauncher =
                registerForActivityResult(

                        new ActivityResultContracts
                                .RequestPermission(),

                        granted -> {

                            if (granted) {

                                pokreniSnimanje();

                            } else {

                                Toast.makeText(
                                        MainActivity.this,

                                        "Dozvola za mikrofon nije odobrena",

                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        });


        // =================================================
        // PRVI BUTTON - SNIMI
        // =================================================

        buttonSnimi.setOnClickListener(
                v -> {

                    proveriMikrofonIPokreni();
                }
        );


        // =================================================
        // DRUGI BUTTON - SAČUVAJ
        // =================================================

        buttonSacuvaj.setOnClickListener(
                v -> {

                    zaustaviSnimanje();
                }
        );


        // =================================================
        // PRVI CHECKBOX
        //
        // GET SVI KORISNICI
        // +
        // ČUVANJE PREKO CONTENT PROVIDER-A
        // =================================================

        checkBoxUsers
                .setOnCheckedChangeListener(

                        (buttonView, isChecked) -> {

                            if (isChecked) {

                                dobaviISacuvajKorisnike();
                            }
                        }
                );


        // =================================================
        // DRUGI CHECKBOX
        //
        // CHECKED:
        // EMAIL 10. KORISNIKA
        //
        // UNCHECKED:
        // PROXIMITY
        // =================================================

        checkBoxTenthUser
                .setOnCheckedChangeListener(

                        (buttonView, isChecked) -> {

                            if (isChecked) {

                                prikaziEmailDesetogKorisnika();

                            } else {

                                prikaziProximity(
                                        lastProximity
                                );
                            }
                        }
                );
    }


    // =====================================================
    // MICROPHONE PERMISSION
    // =====================================================

    private void proveriMikrofonIPokreni() {


        if (ContextCompat
                .checkSelfPermission(

                        this,

                        Manifest.permission.RECORD_AUDIO

                ) == PackageManager.PERMISSION_GRANTED) {


            pokreniSnimanje();


        } else {


            microphonePermissionLauncher.launch(
                    Manifest.permission.RECORD_AUDIO
            );
        }
    }


    // =====================================================
    // AUDIO - START
    // =====================================================

    private void pokreniSnimanje() {


        if (isRecording) {

            return;
        }


        try {


            // =================================================
            // SNIMAK IDE U CACHE DIREKTORIJUM
            // =================================================

            audioFile =
                    new File(

                            getCacheDir(),

                            "snimak_"
                                    + System.currentTimeMillis()
                                    + ".m4a"
                    );


            // =================================================
            // MEDIA RECORDER
            // =================================================

            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.S) {


                mediaRecorder =
                        new MediaRecorder(this);


            } else {


                mediaRecorder =
                        new MediaRecorder();
            }


            mediaRecorder.setAudioSource(
                    MediaRecorder.AudioSource.MIC
            );


            mediaRecorder.setOutputFormat(
                    MediaRecorder.OutputFormat.MPEG_4
            );


            mediaRecorder.setAudioEncoder(
                    MediaRecorder.AudioEncoder.AAC
            );


            mediaRecorder.setOutputFile(
                    audioFile.getAbsolutePath()
            );


            mediaRecorder.prepare();

            mediaRecorder.start();


            isRecording =
                    true;


            buttonSnimi.setEnabled(
                    false
            );


            buttonSacuvaj.setEnabled(
                    true
            );


            Toast.makeText(
                    this,

                    "Snimanje zvuka je pokrenuto",

                    Toast.LENGTH_SHORT
            ).show();


        } catch (IOException e) {


            oslobodiRecorder();


            isRecording =
                    false;


            buttonSnimi.setEnabled(
                    true
            );


            buttonSacuvaj.setEnabled(
                    false
            );


            Toast.makeText(
                    this,

                    "Greška pri snimanju zvuka",

                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================================
    // AUDIO - STOP + SAVE
    // =====================================================

    private void zaustaviSnimanje() {


        if (!isRecording
                || mediaRecorder == null) {


            Toast.makeText(
                    this,

                    "Snimanje nije pokrenuto",

                    Toast.LENGTH_SHORT
            ).show();


            return;
        }


        try {


            mediaRecorder.stop();


            Toast.makeText(
                    this,

                    "Zvuk sačuvan u cache direktorijumu:\n"
                            + audioFile.getName(),

                    Toast.LENGTH_LONG
            ).show();


        } catch (RuntimeException e) {


            // Ako je snimak prekratak,
            // MediaRecorder može napraviti
            // neispravan fajl.

            if (audioFile != null
                    && audioFile.exists()) {


                audioFile.delete();
            }


            Toast.makeText(
                    this,

                    "Snimanje je bilo prekratko",

                    Toast.LENGTH_SHORT
            ).show();


        } finally {


            oslobodiRecorder();


            isRecording =
                    false;


            buttonSnimi.setEnabled(
                    true
            );


            buttonSacuvaj.setEnabled(
                    false
            );
        }
    }


    // =====================================================
    // RELEASE RECORDER
    // =====================================================

    private void oslobodiRecorder() {


        if (mediaRecorder != null) {


            try {

                mediaRecorder.reset();

            } catch (Exception ignored) {

            }


            try {

                mediaRecorder.release();

            } catch (Exception ignored) {

            }


            mediaRecorder =
                    null;
        }
    }


    // =====================================================
    // RETROFIT:
    // GET /users
    // =====================================================

    private void dobaviISacuvajKorisnike() {


        ApiService apiService =
                RetrofitClient
                        .getRetrofit()
                        .create(
                                ApiService.class
                        );


        Call<List<User>> call =
                apiService.getUsers();


        call.enqueue(

                new Callback<List<User>>() {


                    @Override
                    public void onResponse(

                            Call<List<User>> call,

                            Response<List<User>> response) {


                        if (response.isSuccessful()
                                && response.body() != null) {


                            List<User> users =
                                    response.body();


                            sacuvajPrekoContentProvidera(
                                    users
                            );


                        } else {


                            Toast.makeText(
                                    MainActivity.this,

                                    "Greška pri dobijanju korisnika",

                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }


                    @Override
                    public void onFailure(

                            Call<List<User>> call,

                            Throwable t) {


                        Toast.makeText(
                                MainActivity.this,

                                "Retrofit greška: "
                                        + t.getMessage(),

                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        );
    }


    // =====================================================
    // CONTENT PROVIDER:
    // ČUVANJE SVIH KORISNIKA
    // =====================================================

    private void sacuvajPrekoContentProvidera(
            List<User> users) {


        // Prvo brišemo stare podatke
        // da ne dupliramo korisnike.

        getContentResolver()
                .delete(

                        UserContract.CONTENT_URI,

                        null,

                        null
                );


        ContentValues[] valuesArray =
                new ContentValues[
                        users.size()
                        ];


        for (int i = 0;
             i < users.size();
             i++) {


            User user =
                    users.get(i);


            ContentValues values =
                    new ContentValues();


            values.put(
                    UserContract.UserEntry
                            .COLUMN_REMOTE_ID,

                    user.getId()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_NAME,

                    user.getName()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_COMPANY,

                    user.getCompany()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_USERNAME,

                    user.getUsername()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_EMAIL,

                    user.getEmail()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_ADDRESS,

                    user.getAddress()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_ZIP,

                    user.getZip()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_STATE,

                    user.getState()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_COUNTRY,

                    user.getCountry()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_PHONE,

                    user.getPhone()
            );


            values.put(
                    UserContract.UserEntry
                            .COLUMN_PHOTO,

                    user.getPhoto()
            );


            valuesArray[i] =
                    values;
        }


        int inserted =
                getContentResolver()
                        .bulkInsert(

                                UserContract.CONTENT_URI,

                                valuesArray
                        );


        Toast.makeText(
                this,

                "Korisnici sačuvani preko ContentProvider-a: "
                        + inserted,

                Toast.LENGTH_LONG
        ).show();
    }


    // =====================================================
    // EMAIL DESETOG KORISNIKA
    // =====================================================

    private void prikaziEmailDesetogKorisnika() {


        String[] projection =
                new String[]{

                        BaseColumns._ID,

                        UserContract.UserEntry
                                .COLUMN_EMAIL
                };


        Cursor cursor =
                getContentResolver()
                        .query(

                                UserContract.CONTENT_URI,

                                projection,

                                null,

                                null,

                                BaseColumns._ID
                                        + " ASC"
                        );


        if (cursor == null) {


            textViewSecond.setText(
                    "Baza nije dostupna"
            );


            return;
        }


        try {


            // 10. korisnik ima poziciju 9
            // jer indeksiranje kreće od 0.

            if (cursor.getCount() >= 10
                    && cursor.moveToPosition(9)) {


                int emailIndex =
                        cursor.getColumnIndex(
                                UserContract.UserEntry
                                        .COLUMN_EMAIL
                        );


                String email;


                if (emailIndex >= 0) {

                    email =
                            cursor.getString(
                                    emailIndex
                            );

                } else {

                    email =
                            "Email nije pronađen";
                }


                textViewSecond.setText(
                        "Email 10. korisnika:\n"
                                + email
                );


            } else {


                textViewSecond.setText(
                        "Nema desetog korisnika u bazi"
                );
            }


        } finally {


            cursor.close();
        }
    }


    // =====================================================
    // SENZORI
    // =====================================================

    @Override
    public void onSensorChanged(
            SensorEvent event) {


        // =================================================
        // AKCELEROMETAR
        // =================================================

        if (event.sensor.getType()
                == Sensor.TYPE_ACCELEROMETER) {


            accX =
                    event.values[0];

            accY =
                    event.values[1];

            accZ =
                    event.values[2];


            String tekst =
                    String.format(

                            Locale.getDefault(),

                            "Akcelerometar\n"
                                    + "X: %.2f\n"
                                    + "Y: %.2f\n"
                                    + "Z: %.2f",

                            accX,
                            accY,
                            accZ
                    );


            textViewAccelerometer.setText(
                    tekst
            );
        }


        // =================================================
        // PROXIMITY
        // =================================================

        if (event.sensor.getType()
                == Sensor.TYPE_PROXIMITY) {


            lastProximity =
                    event.values[0];


            // Proximity prikazujemo samo kada
            // drugi CheckBox NIJE čekiran.

            if (!checkBoxTenthUser.isChecked()) {


                prikaziProximity(
                        lastProximity
                );


                boolean currentlyFar =
                        lastProximity
                                > PROXIMITY_THRESHOLD;


                // Toast šaljemo kada pređemo
                // iz BLIZU u DALEKO.

                if (previouslyFar != null
                        && !previouslyFar
                        && currentlyFar) {


                    Toast.makeText(
                            this,

                            "Daleko!",

                            Toast.LENGTH_SHORT
                    ).show();
                }


                previouslyFar =
                        currentlyFar;
            }
        }
    }


    // =====================================================
    // PRIKAZ PROXIMITY
    // =====================================================

    private void prikaziProximity(
            float value) {


        String tekst =
                String.format(

                        Locale.getDefault(),

                        "Proximity: %.2f",

                        value
                );


        textViewSecond.setText(
                tekst
        );
    }


    @Override
    public void onAccuracyChanged(
            Sensor sensor,
            int accuracy) {


        // Nije potrebno.
    }


    // =====================================================
    // ON RESUME
    // =====================================================

    @Override
    protected void onResume() {

        super.onResume();


        if (accelerometer != null) {


            sensorManager.registerListener(

                    this,

                    accelerometer,

                    SensorManager.SENSOR_DELAY_NORMAL
            );
        }


        if (proximitySensor != null) {


            sensorManager.registerListener(

                    this,

                    proximitySensor,

                    SensorManager.SENSOR_DELAY_NORMAL
            );
        }
    }


    // =====================================================
    // ON PAUSE
    // =====================================================

    @Override
    protected void onPause() {

        super.onPause();


        sensorManager.unregisterListener(
                this
        );
    }


    // =====================================================
    // ON DESTROY
    // =====================================================

    @Override
    protected void onDestroy() {

        super.onDestroy();


        if (isRecording
                && mediaRecorder != null) {


            try {

                mediaRecorder.stop();

            } catch (Exception ignored) {

            }
        }


        oslobodiRecorder();
    }
}