package com.example.kolokvijum_2c;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDbHelper
        extends SQLiteOpenHelper {


    private static final String DATABASE_NAME =
            "users.db";


    private static final int DATABASE_VERSION =
            1;


    public UserDbHelper(Context context) {

        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }


    @Override
    public void onCreate(
            SQLiteDatabase db) {


        String sql =
                "CREATE TABLE "
                        + UserContract.UserEntry.TABLE_NAME
                        + " ("

                        + UserContract.UserEntry._ID
                        + " INTEGER PRIMARY KEY AUTOINCREMENT, "

                        + UserContract.UserEntry.COLUMN_REMOTE_ID
                        + " INTEGER, "

                        + UserContract.UserEntry.COLUMN_NAME
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_COMPANY
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_USERNAME
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_EMAIL
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_ADDRESS
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_ZIP
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_STATE
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_COUNTRY
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_PHONE
                        + " TEXT, "

                        + UserContract.UserEntry.COLUMN_PHOTO
                        + " TEXT"

                        + ")";


        db.execSQL(sql);
    }


    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {


        db.execSQL(
                "DROP TABLE IF EXISTS "
                        + UserContract.UserEntry.TABLE_NAME
        );


        onCreate(db);
    }
}