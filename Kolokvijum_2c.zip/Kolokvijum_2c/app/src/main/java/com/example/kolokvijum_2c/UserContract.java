package com.example.kolokvijum_2c;

import android.net.Uri;
import android.provider.BaseColumns;

public final class UserContract {

    private UserContract() {
    }


    public static final String AUTHORITY =
            "com.example.kolokvijum_2c.provider";


    public static final Uri CONTENT_URI =
            Uri.parse(
                    "content://"
                            + AUTHORITY
                            + "/users"
            );


    public static class UserEntry
            implements BaseColumns {

        public static final String TABLE_NAME =
                "users";

        public static final String COLUMN_REMOTE_ID =
                "remote_id";

        public static final String COLUMN_NAME =
                "name";

        public static final String COLUMN_COMPANY =
                "company";

        public static final String COLUMN_USERNAME =
                "username";

        public static final String COLUMN_EMAIL =
                "email";

        public static final String COLUMN_ADDRESS =
                "address";

        public static final String COLUMN_ZIP =
                "zip";

        public static final String COLUMN_STATE =
                "state";

        public static final String COLUMN_COUNTRY =
                "country";

        public static final String COLUMN_PHONE =
                "phone";

        public static final String COLUMN_PHOTO =
                "photo";
    }
}