package com.example.kolokvijum_2c;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.Strictness;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    private static final String BASE_URL =
            "https://dummy-json.mock.beeceptor.com/";

    private static Retrofit retrofit;


    public static Retrofit getRetrofit() {

        if (retrofit == null) {

            Gson gson =
                    new GsonBuilder()
                            .setStrictness(Strictness.LENIENT)
                            .create();


            retrofit =
                    new Retrofit.Builder()
                            .baseUrl(BASE_URL)
                            .addConverterFactory(
                                    GsonConverterFactory.create(gson))
                            .build();
        }

        return retrofit;
    }
}