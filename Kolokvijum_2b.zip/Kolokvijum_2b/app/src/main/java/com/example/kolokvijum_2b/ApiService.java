package com.example.kolokvijum_2b;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {

    @GET("countries")
    Call<List<Country>> getCountries();
}