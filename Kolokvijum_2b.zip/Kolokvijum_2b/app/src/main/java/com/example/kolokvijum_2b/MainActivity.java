package com.example.kolokvijum_2b;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity
        implements SensorEventListener {


    // =====================================================
    // UI
    // =====================================================

    private CheckBox checkBoxStopRecording;

    private CheckBox checkBoxCountries;

    private Button buttonSnimi;

    private TextView textViewLocation;

    private TextView textViewProximity;


    // =====================================================
    // LOKACIJA
    // =====================================================

    private LocationManager locationManager;

    private ActivityResultLauncher<String[]>
            locationPermissionLauncher;


    // =====================================================
    // AUDIO
    // =====================================================

    private MediaRecorder mediaRecorder;

    private File audioFile;

    private boolean isRecording = false;

    private ActivityResultLauncher<String>
            microphonePermissionLauncher;


    // =====================================================
    // PROXIMITY
    // =====================================================

    private SensorManager sensorManager;

    private Sensor proximitySensor;


    // =====================================================
    // BAZA
    // =====================================================

    private CountryDbHelper dbHelper;


    // Broj puta kada je drugi CheckBox čekiran.
    //
    // 1. put:
    // GET sve države + čuvanje
    //
    // svaki sledeći put:
    // brisanje poslednje države

    private int countryCheckCount = 0;


    // =====================================================
    // LOCATION LISTENER
    // =====================================================

    private final LocationListener locationListener =
            new LocationListener() {

                @Override
                public void onLocationChanged(
                        Location location) {

                    prikaziLokaciju(location);
                }

                @Override
                public void onProviderEnabled(
                        String provider) {

                }

                @Override
                public void onProviderDisabled(
                        String provider) {

                }
            };


    // =====================================================
    // ON CREATE
    // =====================================================

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_main);


        // =================================================
        // UI
        // =================================================

        checkBoxStopRecording =
                findViewById(
                        R.id.checkBoxStopRecording);

        checkBoxCountries =
                findViewById(
                        R.id.checkBoxCountries);

        buttonSnimi =
                findViewById(
                        R.id.buttonSnimi);

        textViewLocation =
                findViewById(
                        R.id.textViewLocation);

        textViewProximity =
                findViewById(
                        R.id.textViewProximity);


        // =================================================
        // BAZA
        // =================================================

        dbHelper =
                new CountryDbHelper(this);


        // =================================================
        // LOKACIJA
        // =================================================

        locationManager =
                (LocationManager)
                        getSystemService(
                                Context.LOCATION_SERVICE);


        // =================================================
        // PROXIMITY SENSOR
        // =================================================

        sensorManager =
                (SensorManager)
                        getSystemService(
                                Context.SENSOR_SERVICE);


        proximitySensor =
                sensorManager.getDefaultSensor(
                        Sensor.TYPE_PROXIMITY);


        if (proximitySensor == null) {

            textViewProximity.setText(
                    "Proximity senzor nije dostupan");
        }


        // =================================================
        // LOKACIJA - PERMISSION LAUNCHER
        // =================================================

        locationPermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts
                                .RequestMultiplePermissions(),

                        result -> {

                            boolean fine =
                                    Boolean.TRUE.equals(
                                            result.get(
                                                    Manifest.permission
                                                            .ACCESS_FINE_LOCATION));

                            boolean coarse =
                                    Boolean.TRUE.equals(
                                            result.get(
                                                    Manifest.permission
                                                            .ACCESS_COARSE_LOCATION));


                            if (fine || coarse) {

                                pokreniLokaciju();

                            } else {

                                textViewLocation.setText(
                                        "Lokacija: dozvola nije odobrena");
                            }
                        });


        // =================================================
        // MIKROFON - PERMISSION LAUNCHER
        // =================================================

        microphonePermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts
                                .RequestPermission(),

                        granted -> {

                            if (granted) {

                                pokreniSnimanje();

                            } else {

                                Toast.makeText(
                                        MainActivity.this,
                                        "Dozvola za mikrofon nije odobrena",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        });


        // =================================================
        // BUTTON "SNIMI"
        // =================================================

        buttonSnimi.setOnClickListener(v -> {

            proveriMikrofonIPokreniSnimanje();
        });


        // =================================================
        // PRVI CHECKBOX
        //
        // ZAUSTAVLJA AUDIO
        // =================================================

        checkBoxStopRecording
                .setOnCheckedChangeListener(
                        (buttonView, isChecked) -> {

                            if (isChecked) {

                                if (isRecording) {

                                    zaustaviSnimanje();

                                } else {

                                    Toast.makeText(
                                            MainActivity.this,
                                            "Snimanje nije pokrenuto",
                                            Toast.LENGTH_SHORT
                                    ).show();
                                }


                                // Vraćamo checkbox da može
                                // ponovo da se klikne.

                                checkBoxStopRecording
                                        .setChecked(false);
                            }
                        });


        // =================================================
        // DRUGI CHECKBOX
        //
        // PRVI PUT -> GET + BAZA
        //
        // SVAKI SLEDEĆI -> DELETE POSLEDNJU
        // =================================================

        checkBoxCountries
                .setOnCheckedChangeListener(
                        (buttonView, isChecked) -> {

                            if (isChecked) {

                                countryCheckCount++;


                                if (countryCheckCount == 1) {

                                    dobaviISacuvajDrzave();

                                } else {

                                    obrisiPoslednjuDrzavu();
                                }
                            }
                        });


        // =================================================
        // GPS
        // =================================================

        proveriDozvoluZaLokaciju();
    }


    // =====================================================
    // GPS PERMISSION
    // =====================================================

    private void proveriDozvoluZaLokaciju() {

        boolean fine =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission
                                .ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarse =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission
                                .ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        if (fine || coarse) {

            pokreniLokaciju();

        } else {

            locationPermissionLauncher.launch(
                    new String[]{
                            Manifest.permission
                                    .ACCESS_FINE_LOCATION,

                            Manifest.permission
                                    .ACCESS_COARSE_LOCATION
                    }
            );
        }
    }


    // =====================================================
    // GPS
    // =====================================================

    private void pokreniLokaciju() {

        boolean fine =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission
                                .ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarse =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission
                                .ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        if (!fine && !coarse) {

            return;
        }


        try {

            Location poslednjaLokacija = null;


            // =================================================
            // GPS PROVIDER
            // =================================================

            if (fine
                    && locationManager
                    .isProviderEnabled(
                            LocationManager.GPS_PROVIDER)) {


                poslednjaLokacija =
                        locationManager
                                .getLastKnownLocation(
                                        LocationManager
                                                .GPS_PROVIDER);


                locationManager
                        .requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                1000,
                                1,
                                locationListener
                        );
            }


            // =================================================
            // NETWORK PROVIDER
            // =================================================

            if (locationManager
                    .isProviderEnabled(
                            LocationManager
                                    .NETWORK_PROVIDER)) {


                Location networkLocation =
                        locationManager
                                .getLastKnownLocation(
                                        LocationManager
                                                .NETWORK_PROVIDER);


                if (networkLocation != null) {

                    if (poslednjaLokacija == null
                            || networkLocation.getTime()
                            > poslednjaLokacija.getTime()) {

                        poslednjaLokacija =
                                networkLocation;
                    }
                }


                locationManager
                        .requestLocationUpdates(
                                LocationManager
                                        .NETWORK_PROVIDER,
                                1000,
                                1,
                                locationListener
                        );
            }


            if (poslednjaLokacija != null) {

                prikaziLokaciju(
                        poslednjaLokacija);

            } else {

                textViewLocation.setText(
                        "Lokacija: čekanje GPS signala...");
            }


        } catch (SecurityException e) {

            textViewLocation.setText(
                    "Greška pri pristupu lokaciji");
        }
    }


    // =====================================================
    // PRIKAZ GPS-A
    // =====================================================

    private void prikaziLokaciju(
            Location location) {

        String tekst =
                String.format(
                        Locale.getDefault(),

                        "Geografska širina: %.6f\n"
                                + "Geografska dužina: %.6f",

                        location.getLatitude(),
                        location.getLongitude()
                );


        textViewLocation.setText(
                tekst);
    }


    // =====================================================
    // PROVERA MIKROFONA
    // =====================================================

    private void proveriMikrofonIPokreniSnimanje() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED) {

            pokreniSnimanje();

        } else {

            microphonePermissionLauncher.launch(
                    Manifest.permission.RECORD_AUDIO
            );
        }
    }


    // =====================================================
    // POKRETANJE SNIMANJA
    // =====================================================

    private void pokreniSnimanje() {

        if (isRecording) {

            return;
        }


        try {

            // =================================================
            // FAJL U INTERNAL FILES DIREKTORIJUMU
            // =================================================

            audioFile =
                    new File(
                            getFilesDir(),

                            "snimak_"
                                    + System.currentTimeMillis()
                                    + ".m4a"
                    );


            // =================================================
            // MEDIA RECORDER
            // =================================================

            if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.S) {

                mediaRecorder =
                        new MediaRecorder(this);

            } else {

                mediaRecorder =
                        new MediaRecorder();
            }


            mediaRecorder.setAudioSource(
                    MediaRecorder.AudioSource.MIC);


            mediaRecorder.setOutputFormat(
                    MediaRecorder.OutputFormat.MPEG_4);


            mediaRecorder.setAudioEncoder(
                    MediaRecorder.AudioEncoder.AAC);


            mediaRecorder.setOutputFile(
                    audioFile.getAbsolutePath());


            mediaRecorder.prepare();

            mediaRecorder.start();


            isRecording = true;


            // =================================================
            // DUGME SE ONEMOGUĆAVA
            // =================================================

            buttonSnimi.setEnabled(false);


            Toast.makeText(
                    this,
                    "Snimanje zvuka je pokrenuto",
                    Toast.LENGTH_SHORT
            ).show();


        } catch (IOException e) {

            oslobodiRecorder();


            buttonSnimi.setEnabled(true);


            Toast.makeText(
                    this,
                    "Greška pri pokretanju snimanja",
                    Toast.LENGTH_LONG
            ).show();
        }
    }


    // =====================================================
    // ZAUSTAVLJANJE SNIMANJA
    // =====================================================

    private void zaustaviSnimanje() {

        if (!isRecording
                || mediaRecorder == null) {

            return;
        }


        try {

            mediaRecorder.stop();


            Toast.makeText(
                    this,

                    "Zvuk sačuvan u files direktorijumu:\n"
                            + audioFile.getName(),

                    Toast.LENGTH_LONG
            ).show();


        } catch (RuntimeException e) {

            // Ako je snimanje bilo prekratko,
            // MediaRecorder nekad ne napravi validan fajl.

            if (audioFile != null
                    && audioFile.exists()) {

                audioFile.delete();
            }


            Toast.makeText(
                    this,
                    "Snimanje je bilo prekratko",
                    Toast.LENGTH_SHORT
            ).show();


        } finally {

            oslobodiRecorder();


            isRecording = false;


            // =================================================
            // DUGME PONOVO MOŽE DA SE KLIKNE
            // =================================================

            buttonSnimi.setEnabled(true);
        }
    }


    // =====================================================
    // RELEASE MEDIA RECORDER
    // =====================================================

    private void oslobodiRecorder() {

        if (mediaRecorder != null) {

            try {

                mediaRecorder.reset();

            } catch (Exception ignored) {

            }


            try {

                mediaRecorder.release();

            } catch (Exception ignored) {

            }


            mediaRecorder = null;
        }
    }


    // =====================================================
    // RETROFIT:
    // DOBAVI SVE DRŽAVE I SAČUVAJ U BAZI
    // =====================================================

    private void dobaviISacuvajDrzave() {

        ApiService apiService =
                RetrofitClient
                        .getRetrofit()
                        .create(ApiService.class);


        Call<List<Country>> call =
                apiService.getCountries();


        call.enqueue(
                new Callback<List<Country>>() {


                    @Override
                    public void onResponse(
                            Call<List<Country>> call,
                            Response<List<Country>> response) {


                        if (response.isSuccessful()
                                && response.body() != null) {


                            List<Country> countries =
                                    response.body();


                            // Brišemo stare podatke
                            // da ne dupliramo države.

                            dbHelper.deleteAllCountries();


                            // Čuvamo sve države.

                            dbHelper.insertCountries(
                                    countries);


                            int count =
                                    dbHelper.getCountryCount();


                            Toast.makeText(
                                    MainActivity.this,

                                    "Države sačuvane u bazi: "
                                            + count,

                                    Toast.LENGTH_LONG
                            ).show();


                        } else {


                            // Ako GET nije uspeo,
                            // omogućavamo da sledeće čekiranje
                            // ponovo bude pokušaj preuzimanja.

                            countryCheckCount = 0;


                            Toast.makeText(
                                    MainActivity.this,
                                    "Greška pri dobijanju država",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }


                    @Override
                    public void onFailure(
                            Call<List<Country>> call,
                            Throwable t) {


                        countryCheckCount = 0;


                        Toast.makeText(
                                MainActivity.this,

                                "Retrofit greška: "
                                        + t.getMessage(),

                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }


    // =====================================================
    // BRIŠI POSLEDNJU DRŽAVU
    // =====================================================

    private void obrisiPoslednjuDrzavu() {

        boolean deleted =
                dbHelper.deleteLastCountry();


        int remaining =
                dbHelper.getCountryCount();


        if (deleted) {

            Toast.makeText(
                    this,

                    "Preostalo država u bazi: "
                            + remaining,

                    Toast.LENGTH_LONG
            ).show();

        } else {

            Toast.makeText(
                    this,
                    "Nema više država u bazi",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================================
    // PROXIMITY SENZOR
    // =====================================================

    @Override
    public void onSensorChanged(
            SensorEvent event) {


        if (event.sensor.getType()
                == Sensor.TYPE_PROXIMITY) {


            float vrednost =
                    event.values[0];


            String tekst =
                    String.format(
                            Locale.getDefault(),
                            "Proximity: %.2f",
                            vrednost
                    );


            textViewProximity.setText(
                    tekst);
        }
    }


    @Override
    public void onAccuracyChanged(
            Sensor sensor,
            int accuracy) {

        // Nije potrebno.
    }


    // =====================================================
    // ON RESUME
    // =====================================================

    @Override
    protected void onResume() {

        super.onResume();


        if (proximitySensor != null) {

            sensorManager.registerListener(
                    this,
                    proximitySensor,
                    SensorManager.SENSOR_DELAY_NORMAL
            );
        }
    }


    // =====================================================
    // ON PAUSE
    // =====================================================

    @Override
    protected void onPause() {

        super.onPause();


        sensorManager.unregisterListener(
                this);
    }


    // =====================================================
    // ON DESTROY
    // =====================================================

    @Override
    protected void onDestroy() {

        super.onDestroy();


        // =================================================
        // ZAUSTAVI AUDIO AKO JE OSTAO UKLJUČEN
        // =================================================

        if (isRecording
                && mediaRecorder != null) {

            try {

                mediaRecorder.stop();

            } catch (Exception ignored) {

            }
        }


        oslobodiRecorder();


        // =================================================
        // LOCATION LISTENER
        // =================================================

        if (locationManager != null) {

            try {

                locationManager.removeUpdates(
                        locationListener);

            } catch (SecurityException ignored) {

            }
        }


        // =================================================
        // DATABASE
        // =================================================

        if (dbHelper != null) {

            dbHelper.close();
        }
    }
}