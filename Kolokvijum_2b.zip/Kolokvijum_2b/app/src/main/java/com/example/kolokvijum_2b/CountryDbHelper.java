package com.example.kolokvijum_2b;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;

public class CountryDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME =
            "countries.db";

    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_COUNTRIES =
            "countries";

    private static final String COLUMN_ID =
            "id";

    private static final String COLUMN_NAME =
            "name";

    private static final String COLUMN_CODE =
            "code";


    public CountryDbHelper(Context context) {

        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql =
                "CREATE TABLE "
                        + TABLE_COUNTRIES
                        + " ("
                        + COLUMN_ID
                        + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + COLUMN_NAME
                        + " TEXT NOT NULL, "
                        + COLUMN_CODE
                        + " TEXT NOT NULL"
                        + ")";

        db.execSQL(sql);
    }


    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        db.execSQL(
                "DROP TABLE IF EXISTS "
                        + TABLE_COUNTRIES);

        onCreate(db);
    }


    // =====================================================
    // BRIŠI SVE
    // =====================================================

    public void deleteAllCountries() {

        SQLiteDatabase db =
                getWritableDatabase();

        db.delete(
                TABLE_COUNTRIES,
                null,
                null
        );
    }


    // =====================================================
    // SAČUVAJ SVE DRŽAVE
    // =====================================================

    public void insertCountries(
            List<Country> countries) {

        SQLiteDatabase db =
                getWritableDatabase();

        db.beginTransaction();

        try {

            for (Country country : countries) {

                ContentValues values =
                        new ContentValues();

                values.put(
                        COLUMN_NAME,
                        country.getName()
                );

                values.put(
                        COLUMN_CODE,
                        country.getCode()
                );

                db.insert(
                        TABLE_COUNTRIES,
                        null,
                        values
                );
            }

            db.setTransactionSuccessful();

        } finally {

            db.endTransaction();
        }
    }


    // =====================================================
    // BROJ DRŽAVA
    // =====================================================

    public int getCountryCount() {

        SQLiteDatabase db =
                getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM "
                                + TABLE_COUNTRIES,
                        null
                );

        int count = 0;

        if (cursor.moveToFirst()) {

            count =
                    cursor.getInt(0);
        }

        cursor.close();

        return count;
    }


    // =====================================================
    // OBRIŠI POSLEDNJU DRŽAVU
    // =====================================================

    public boolean deleteLastCountry() {

        SQLiteDatabase db =
                getWritableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT "
                                + COLUMN_ID
                                + " FROM "
                                + TABLE_COUNTRIES
                                + " ORDER BY "
                                + COLUMN_ID
                                + " DESC LIMIT 1",
                        null
                );


        if (cursor.moveToFirst()) {

            long id =
                    cursor.getLong(0);

            cursor.close();

            int deleted =
                    db.delete(
                            TABLE_COUNTRIES,
                            COLUMN_ID + " = ?",
                            new String[]{
                                    String.valueOf(id)
                            }
                    );

            return deleted > 0;
        }


        cursor.close();

        return false;
    }
}