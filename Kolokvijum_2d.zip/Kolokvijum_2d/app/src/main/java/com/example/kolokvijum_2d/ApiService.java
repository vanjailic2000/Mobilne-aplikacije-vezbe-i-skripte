package com.example.kolokvijum_2d;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {

    @GET("continents")
    Call<List<Continent>> getContinents();
}