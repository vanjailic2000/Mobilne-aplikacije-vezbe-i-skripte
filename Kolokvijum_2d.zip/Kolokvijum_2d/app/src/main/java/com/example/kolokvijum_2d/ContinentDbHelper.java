package com.example.kolokvijum_2d;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;

public class ContinentDbHelper
        extends SQLiteOpenHelper {


    private static final String DATABASE_NAME =
            "continents.db";

    private static final int DATABASE_VERSION =
            1;


    private static final String TABLE_CONTINENTS =
            "continents";

    private static final String COLUMN_ID =
            "id";

    private static final String COLUMN_CODE =
            "code";

    private static final String COLUMN_NAME =
            "name";

    private static final String COLUMN_POPULATION =
            "population";

    private static final String COLUMN_COUNTRIES =
            "countries";


    public ContinentDbHelper(
            Context context) {

        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }


    @Override
    public void onCreate(
            SQLiteDatabase db) {

        String sql =
                "CREATE TABLE "
                        + TABLE_CONTINENTS
                        + " ("

                        + COLUMN_ID
                        + " INTEGER PRIMARY KEY AUTOINCREMENT, "

                        + COLUMN_CODE
                        + " TEXT, "

                        + COLUMN_NAME
                        + " TEXT, "

                        + COLUMN_POPULATION
                        + " INTEGER, "

                        + COLUMN_COUNTRIES
                        + " INTEGER"

                        + ")";


        db.execSQL(sql);
    }


    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        db.execSQL(
                "DROP TABLE IF EXISTS "
                        + TABLE_CONTINENTS
        );

        onCreate(db);
    }


    // =====================================================
    // SAČUVAJ SAMO KONTINENTE
    // SA POPULACIJOM > 10000
    // =====================================================

    public int saveContinentsAbove10000(
            List<Continent> continents) {


        SQLiteDatabase db =
                getWritableDatabase();


        // Brišemo stare podatke da ih ne dupliramo.

        db.delete(
                TABLE_CONTINENTS,
                null,
                null
        );


        int saved =
                0;


        db.beginTransaction();


        try {

            for (Continent continent : continents) {


                if (continent.getPopulation()
                        > 10000) {


                    ContentValues values =
                            new ContentValues();


                    values.put(
                            COLUMN_CODE,
                            continent.getCode()
                    );


                    values.put(
                            COLUMN_NAME,
                            continent.getName()
                    );


                    values.put(
                            COLUMN_POPULATION,
                            continent.getPopulation()
                    );


                    values.put(
                            COLUMN_COUNTRIES,
                            continent.getCountries()
                    );


                    long result =
                            db.insert(
                                    TABLE_CONTINENTS,
                                    null,
                                    values
                            );


                    if (result != -1) {

                        saved++;
                    }
                }
            }


            db.setTransactionSuccessful();


        } finally {

            db.endTransaction();
        }


        return saved;
    }


    // =====================================================
    // BROJ DRŽAVA TREĆEG KONTINENTA
    // =====================================================

    public Integer getThirdContinentCountries() {


        SQLiteDatabase db =
                getReadableDatabase();


        Cursor cursor =
                db.rawQuery(

                        "SELECT "
                                + COLUMN_COUNTRIES
                                + " FROM "
                                + TABLE_CONTINENTS
                                + " ORDER BY "
                                + COLUMN_ID
                                + " ASC LIMIT 1 OFFSET 2",

                        null
                );


        Integer countries =
                null;


        if (cursor.moveToFirst()) {

            countries =
                    cursor.getInt(0);
        }


        cursor.close();


        return countries;
    }
}