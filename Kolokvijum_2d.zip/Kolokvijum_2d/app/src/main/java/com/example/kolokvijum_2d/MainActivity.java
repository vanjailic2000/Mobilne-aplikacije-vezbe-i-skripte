package com.example.kolokvijum_2d;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity
        extends AppCompatActivity
        implements SensorEventListener {


    // =====================================================
    // UI
    // =====================================================

    private CheckBox checkBoxContinents;

    private CheckBox checkBoxThirdContinent;

    private ImageButton imageButtonCamera;

    private TextView textViewProximity;

    private TextView textViewSecond;


    // =====================================================
    // PROXIMITY
    // =====================================================

    private SensorManager sensorManager;

    private Sensor proximitySensor;


    // Proizvoljan prag.

    private static final float
            PROXIMITY_THRESHOLD = 0.5f;


    private Boolean previouslyNear =
            null;


    // =====================================================
    // KAMERA
    // =====================================================

    private File photoFile;

    private Uri photoUri;

    private ActivityResultLauncher<Uri>
            cameraLauncher;


    // =====================================================
    // BAZA
    // =====================================================

    private ContinentDbHelper dbHelper;


    // =====================================================
    // LOKACIJA
    // =====================================================

    private LocationManager locationManager;

    private Location lastLocation;


    private ActivityResultLauncher<String[]>
            locationPermissionLauncher;


    // =====================================================
    // LOCATION LISTENER
    // =====================================================

    private final LocationListener
            locationListener =
            new LocationListener() {


                @Override
                public void onLocationChanged(
                        Location location) {


                    lastLocation =
                            location;


                    // Lokaciju prikazujemo samo kada
                    // DRUGI CHECKBOX NIJE čekiran.

                    if (!checkBoxThirdContinent
                            .isChecked()) {


                        prikaziLokaciju(
                                location
                        );
                    }
                }


                @Override
                public void onProviderEnabled(
                        String provider) {

                }


                @Override
                public void onProviderDisabled(
                        String provider) {

                }
            };


    // =====================================================
    // ON CREATE
    // =====================================================

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {


        super.onCreate(
                savedInstanceState
        );


        setContentView(
                R.layout.activity_main
        );


        // =================================================
        // UI
        // =================================================

        checkBoxContinents =
                findViewById(
                        R.id.checkBoxContinents
                );


        checkBoxThirdContinent =
                findViewById(
                        R.id.checkBoxThirdContinent
                );


        imageButtonCamera =
                findViewById(
                        R.id.imageButtonCamera
                );


        textViewProximity =
                findViewById(
                        R.id.textViewProximity
                );


        textViewSecond =
                findViewById(
                        R.id.textViewSecond
                );


        // =================================================
        // BAZA
        // =================================================

        dbHelper =
                new ContinentDbHelper(
                        this
                );


        // =================================================
        // PROXIMITY
        // =================================================

        sensorManager =
                (SensorManager)
                        getSystemService(
                                Context.SENSOR_SERVICE
                        );


        proximitySensor =
                sensorManager.getDefaultSensor(
                        Sensor.TYPE_PROXIMITY
                );


        if (proximitySensor == null) {

            textViewProximity.setText(
                    "Proximity senzor nije dostupan"
            );
        }


        // =================================================
        // LOCATION
        // =================================================

        locationManager =
                (LocationManager)
                        getSystemService(
                                Context.LOCATION_SERVICE
                        );


        // =================================================
        // LOCATION PERMISSION
        // =================================================

        locationPermissionLauncher =
                registerForActivityResult(

                        new ActivityResultContracts
                                .RequestMultiplePermissions(),

                        result -> {


                            boolean fine =
                                    Boolean.TRUE.equals(

                                            result.get(
                                                    Manifest.permission
                                                            .ACCESS_FINE_LOCATION
                                            )
                                    );


                            boolean coarse =
                                    Boolean.TRUE.equals(

                                            result.get(
                                                    Manifest.permission
                                                            .ACCESS_COARSE_LOCATION
                                            )
                                    );


                            if (fine || coarse) {

                                pokreniLokaciju();

                            } else {

                                textViewSecond.setText(
                                        "Lokacija: dozvola nije odobrena"
                                );
                            }
                        }
                );


        // =================================================
        // CAMERA RESULT
        // =================================================

        cameraLauncher =
                registerForActivityResult(

                        new ActivityResultContracts
                                .TakePicture(),

                        success -> {


                            if (success
                                    && photoFile != null) {


                                // =================================
                                // TAČKA 4:
                                // PUTANJA U TOAST PORUCI
                                // =================================

                                Toast.makeText(
                                        MainActivity.this,

                                        "Slika sačuvana:\n"
                                                + photoFile
                                                .getAbsolutePath(),

                                        Toast.LENGTH_LONG
                                ).show();


                            } else {


                                // Ako je korisnik odustao,
                                // možemo obrisati prazan fajl.

                                if (photoFile != null
                                        && photoFile.exists()) {


                                    photoFile.delete();
                                }


                                Toast.makeText(
                                        MainActivity.this,

                                        "Snimanje otkazano",

                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                );


        // =================================================
        // IMAGE BUTTON - KAMERA
        // =================================================

        imageButtonCamera
                .setOnClickListener(
                        v -> {

                            pokreniKameru();
                        }
                );


        // =================================================
        // PRVI CHECKBOX:
        //
        // GET SVI KONTINENTI
        //
        // U BAZU SAMO POPULACIJA > 10000
        // =================================================

        checkBoxContinents
                .setOnCheckedChangeListener(

                        (buttonView, isChecked) -> {


                            if (isChecked) {

                                dobaviISacuvajKontinente();
                            }
                        }
                );


        // =================================================
        // DRUGI CHECKBOX
        //
        // CHECKED:
        // BROJ DRŽAVA TREĆEG KONTINENTA
        //
        // UNCHECKED:
        // LOKACIJA
        // =================================================

        checkBoxThirdContinent
                .setOnCheckedChangeListener(

                        (buttonView, isChecked) -> {


                            if (isChecked) {


                                prikaziBrojDrzavaTrecegKontinenta();


                            } else {


                                if (lastLocation != null) {


                                    prikaziLokaciju(
                                            lastLocation
                                    );


                                } else {


                                    textViewSecond.setText(
                                            "Lokacija: čekanje..."
                                    );
                                }
                            }
                        }
                );


        // =================================================
        // GPS
        // =================================================

        proveriDozvoluZaLokaciju();
    }


    // =====================================================
    // PROXIMITY SENZOR
    // =====================================================

    @Override
    public void onSensorChanged(
            SensorEvent event) {


        if (event.sensor.getType()
                == Sensor.TYPE_PROXIMITY) {


            float proximity =
                    event.values[0];


            textViewProximity.setText(

                    String.format(

                            Locale.getDefault(),

                            "Proximity: %.2f",

                            proximity
                    )
            );


            boolean currentlyNear =
                    proximity
                            < PROXIMITY_THRESHOLD;


            // Toast šaljemo kada je ispod praga.
            //
            // Ne šaljemo ga 100 puta za redom,
            // nego samo kada pređemo u BLIZU.

            if (currentlyNear
                    && (previouslyNear == null
                    || !previouslyNear)) {


                Toast.makeText(
                        this,

                        "Blizu!",

                        Toast.LENGTH_SHORT
                ).show();
            }


            previouslyNear =
                    currentlyNear;
        }
    }


    @Override
    public void onAccuracyChanged(
            Sensor sensor,
            int accuracy) {


        // Nije potrebno.
    }


    // =====================================================
    // KAMERA
    // =====================================================

    private void pokreniKameru() {


        try {


            // =================================================
            // CACHE/IMAGES
            // =================================================

            File imagesDirectory =
                    new File(

                            getCacheDir(),

                            "images"
                    );


            if (!imagesDirectory.exists()) {

                imagesDirectory.mkdirs();
            }


            // =================================================
            // NOVA SLIKA
            // =================================================

            photoFile =
                    File.createTempFile(

                            "slika_",

                            ".jpg",

                            imagesDirectory
                    );


            // =================================================
            // FILE PROVIDER URI
            // =================================================

            photoUri =
                    FileProvider.getUriForFile(

                            this,

                            getPackageName()
                                    + ".fileprovider",

                            photoFile
                    );


            // =================================================
            // POKRENI KAMERU
            // =================================================

            cameraLauncher.launch(
                    photoUri
            );


        } catch (IOException e) {


            Toast.makeText(
                    this,

                    "Greška pri kreiranju slike",

                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================================
    // RETROFIT:
    // DOBAVI KONTINENTE
    // =====================================================

    private void dobaviISacuvajKontinente() {


        ApiService apiService =
                RetrofitClient
                        .getRetrofit()
                        .create(
                                ApiService.class
                        );


        Call<List<Continent>> call =
                apiService.getContinents();


        call.enqueue(

                new Callback<List<Continent>>() {


                    @Override
                    public void onResponse(

                            Call<List<Continent>> call,

                            Response<List<Continent>> response) {


                        if (response.isSuccessful()
                                && response.body() != null) {


                            List<Continent> continents =
                                    response.body();


                            // =================================
                            // U BAZU SAMO POPULACIJA > 10000
                            // =================================

                            int saved =
                                    dbHelper
                                            .saveContinentsAbove10000(
                                                    continents
                                            );


                            Toast.makeText(
                                    MainActivity.this,

                                    "Sačuvano kontinenata u bazi: "
                                            + saved,

                                    Toast.LENGTH_LONG
                            ).show();


                        } else {


                            Toast.makeText(
                                    MainActivity.this,

                                    "Greška pri dobijanju kontinenata",

                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }


                    @Override
                    public void onFailure(

                            Call<List<Continent>> call,

                            Throwable t) {


                        Toast.makeText(
                                MainActivity.this,

                                "Retrofit greška: "
                                        + t.getMessage(),

                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        );
    }


    // =====================================================
    // TREĆI KONTINENT IZ BAZE
    // =====================================================

    private void prikaziBrojDrzavaTrecegKontinenta() {


        Integer countries =
                dbHelper
                        .getThirdContinentCountries();


        if (countries != null) {


            textViewSecond.setText(

                    "Broj država trećeg kontinenta: "
                            + countries
            );


        } else {


            textViewSecond.setText(

                    "Nema trećeg kontinenta u bazi"
            );


            Toast.makeText(
                    this,

                    "Prvo čekiraj Dobavi kontinente",

                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================================
    // LOCATION PERMISSION
    // =====================================================

    private void proveriDozvoluZaLokaciju() {


        boolean fine =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_FINE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarse =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_COARSE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        if (fine || coarse) {


            pokreniLokaciju();


        } else {


            locationPermissionLauncher.launch(

                    new String[]{

                            Manifest.permission
                                    .ACCESS_FINE_LOCATION,

                            Manifest.permission
                                    .ACCESS_COARSE_LOCATION
                    }
            );
        }
    }


    // =====================================================
    // LOCATION
    // =====================================================

    private void pokreniLokaciju() {


        boolean fine =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_FINE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarse =
                ContextCompat.checkSelfPermission(

                        this,

                        Manifest.permission
                                .ACCESS_COARSE_LOCATION

                ) == PackageManager.PERMISSION_GRANTED;


        if (!fine && !coarse) {

            return;
        }


        try {


            Location location =
                    null;


            // =================================================
            // GPS
            // =================================================

            if (fine
                    && locationManager
                    .isProviderEnabled(
                            LocationManager.GPS_PROVIDER
                    )) {


                location =
                        locationManager
                                .getLastKnownLocation(
                                        LocationManager
                                                .GPS_PROVIDER
                                );


                locationManager
                        .requestLocationUpdates(

                                LocationManager.GPS_PROVIDER,

                                1000,

                                1,

                                locationListener
                        );
            }


            // =================================================
            // NETWORK LOCATION
            // =================================================

            if (locationManager
                    .isProviderEnabled(
                            LocationManager.NETWORK_PROVIDER
                    )) {


                Location networkLocation =
                        locationManager
                                .getLastKnownLocation(

                                        LocationManager
                                                .NETWORK_PROVIDER
                                );


                if (networkLocation != null) {


                    if (location == null
                            || networkLocation.getTime()
                            > location.getTime()) {


                        location =
                                networkLocation;
                    }
                }


                locationManager
                        .requestLocationUpdates(

                                LocationManager.NETWORK_PROVIDER,

                                1000,

                                1,

                                locationListener
                        );
            }


            // =================================================
            // PRIKAŽI POSLEDNJU POZNATU
            // =================================================

            if (location != null) {


                lastLocation =
                        location;


                if (!checkBoxThirdContinent
                        .isChecked()) {


                    prikaziLokaciju(
                            location
                    );
                }


            } else {


                textViewSecond.setText(
                        "Lokacija: čekanje GPS signala..."
                );
            }


        } catch (SecurityException e) {


            textViewSecond.setText(
                    "Greška pri pristupu lokaciji"
            );
        }
    }


    // =====================================================
    // PRIKAZ LOKACIJE
    // =====================================================

    private void prikaziLokaciju(
            Location location) {


        String tekst =
                String.format(

                        Locale.getDefault(),

                        "Geografska širina: %.6f\n"
                                + "Geografska dužina: %.6f",

                        location.getLatitude(),

                        location.getLongitude()
                );


        textViewSecond.setText(
                tekst
        );
    }


    // =====================================================
    // ON RESUME
    // =====================================================

    @Override
    protected void onResume() {


        super.onResume();


        if (proximitySensor != null) {


            sensorManager.registerListener(

                    this,

                    proximitySensor,

                    SensorManager.SENSOR_DELAY_NORMAL
            );
        }
    }


    // =====================================================
    // ON PAUSE
    // =====================================================

    @Override
    protected void onPause() {


        super.onPause();


        sensorManager.unregisterListener(
                this
        );
    }


    // =====================================================
    // ON DESTROY
    // =====================================================

    @Override
    protected void onDestroy() {


        super.onDestroy();


        if (locationManager != null) {


            try {


                locationManager.removeUpdates(
                        locationListener
                );


            } catch (SecurityException ignored) {

            }
        }


        if (dbHelper != null) {

            dbHelper.close();
        }
    }
}