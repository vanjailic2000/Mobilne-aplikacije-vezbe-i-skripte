package com.example.kolokvijum_2a;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiService {

    @GET("roles/{role_id}")
    Call<Role> getRole(@Path("role_id") int roleId);
}