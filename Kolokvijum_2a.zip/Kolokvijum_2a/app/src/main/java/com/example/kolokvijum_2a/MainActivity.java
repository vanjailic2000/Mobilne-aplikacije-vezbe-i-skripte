package com.example.kolokvijum_2a;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity
        implements SensorEventListener {

    // =====================================================
    // KOMPONENTE
    // =====================================================

    private TextView textViewLocation;
    private CheckBox checkBoxRole;
    private Button buttonSnimi;
    private ImageView imageViewPhoto;


    // =====================================================
    // LOKACIJA
    // =====================================================

    private LocationManager locationManager;


    // =====================================================
    // KAMERA
    // =====================================================

    private Uri photoUri;


    // =====================================================
    // SENZORI
    // =====================================================

    private SensorManager sensorManager;

    private Sensor accelerometer;
    private Sensor gyroscope;

    private float accX = 0;
    private float accY = 0;
    private float accZ = 0;

    private float gyroX = 0;
    private float gyroY = 0;
    private float gyroZ = 0;


    // =====================================================
    // CHECKBOX
    // =====================================================

    private int brojCekiranja = 0;


    // =====================================================
    // ACTIVITY RESULT LAUNCHERI
    // =====================================================

    private ActivityResultLauncher<String[]> locationPermissionLauncher;

    private ActivityResultLauncher<Uri> cameraLauncher;


    // =====================================================
    // LOCATION LISTENER
    // =====================================================

    private final LocationListener locationListener =
            new LocationListener() {

                @Override
                public void onLocationChanged(Location location) {

                    prikaziLokaciju(location);
                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            };


    // =====================================================
    // ON CREATE
    // =====================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        // =================================================
        // POVEZIVANJE XML KOMPONENTI
        // =================================================

        textViewLocation =
                findViewById(R.id.textViewLocation);

        checkBoxRole =
                findViewById(R.id.checkBoxRole);

        buttonSnimi =
                findViewById(R.id.buttonSnimi);

        imageViewPhoto =
                findViewById(R.id.imageViewPhoto);


        // =================================================
        // SENSOR MANAGER
        // =================================================

        sensorManager =
                (SensorManager) getSystemService(
                        Context.SENSOR_SERVICE);


        accelerometer =
                sensorManager.getDefaultSensor(
                        Sensor.TYPE_ACCELEROMETER);


        gyroscope =
                sensorManager.getDefaultSensor(
                        Sensor.TYPE_GYROSCOPE);


        // =================================================
        // LOCATION MANAGER
        // =================================================

        locationManager =
                (LocationManager) getSystemService(
                        Context.LOCATION_SERVICE);


        // =================================================
        // DOZVOLA ZA LOKACIJU
        // =================================================

        locationPermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.RequestMultiplePermissions(),
                        result -> {

                            boolean fineLocation =
                                    Boolean.TRUE.equals(
                                            result.get(
                                                    Manifest.permission.ACCESS_FINE_LOCATION));


                            boolean coarseLocation =
                                    Boolean.TRUE.equals(
                                            result.get(
                                                    Manifest.permission.ACCESS_COARSE_LOCATION));


                            if (fineLocation || coarseLocation) {

                                pokreniLokaciju();

                            } else {

                                textViewLocation.setText(
                                        "Lokacija: dozvola nije odobrena");
                            }
                        });


        // =================================================
        // KAMERA
        // =================================================

        cameraLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.TakePicture(),
                        uspesnoSnimanje -> {

                            if (uspesnoSnimanje
                                    && photoUri != null) {

                                // =====================================
                                // FOTOGRAFIJA JE SNIMLJENA
                                // =====================================

                                imageViewPhoto.setImageURI(null);

                                imageViewPhoto.setImageURI(photoUri);


                                // =====================================
                                // TOAST SA AKCELEROMETROM
                                // =====================================

                                String poruka =
                                        String.format(
                                                Locale.getDefault(),
                                                "Akcelerometar\nX: %.2f\nY: %.2f\nZ: %.2f",
                                                accX,
                                                accY,
                                                accZ);


                                Toast.makeText(
                                        MainActivity.this,
                                        poruka,
                                        Toast.LENGTH_LONG
                                ).show();


                                // Ako je prethodno korisnik odustao,
                                // vraćamo tekst dugmeta.

                                buttonSnimi.setText("Snimi");

                            } else {

                                // =====================================
                                // KORISNIK JE ODUSTAO OD SNIMANJA
                                // =====================================

                                String gyroText =
                                        String.format(
                                                Locale.getDefault(),
                                                "X: %.2f Y: %.2f Z: %.2f",
                                                gyroX,
                                                gyroY,
                                                gyroZ);


                                buttonSnimi.setText(gyroText);
                            }
                        });


        // =================================================
        // BUTTON SNIMI
        // =================================================

        buttonSnimi.setOnClickListener(v -> {

            otvoriKameru();

        });


        // =================================================
        // CHECKBOX
        // =================================================

        checkBoxRole.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    // Računamo samo prelazak na CHECKED.

                    if (isChecked) {

                        brojCekiranja++;

                        // Prvo čekiranje -> ID 1
                        // Drugo čekiranje -> ID 2
                        // Treće čekiranje -> ID 3...

                        dobaviUlogu(brojCekiranja);
                    }
                });


        // =================================================
        // LOKACIJA
        // =================================================

        proveriDozvoluZaLokaciju();
    }


    // =====================================================
    // LOKACIJA - PROVERA DOZVOLE
    // =====================================================

    private void proveriDozvoluZaLokaciju() {

        boolean fineLocation =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarseLocation =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        if (fineLocation || coarseLocation) {

            pokreniLokaciju();

        } else {

            locationPermissionLauncher.launch(
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    });
        }
    }


    // =====================================================
    // LOKACIJA - POKRETANJE
    // =====================================================

    private void pokreniLokaciju() {

        boolean fineLocation =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        boolean coarseLocation =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED;


        if (!fineLocation && !coarseLocation) {

            return;
        }


        try {

            Location poslednjaLokacija = null;


            // =================================================
            // GPS
            // =================================================

            if (fineLocation
                    && locationManager.isProviderEnabled(
                    LocationManager.GPS_PROVIDER)) {


                poslednjaLokacija =
                        locationManager.getLastKnownLocation(
                                LocationManager.GPS_PROVIDER);


                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        1000,
                        1,
                        locationListener);
            }


            // =================================================
            // NETWORK LOCATION
            // =================================================

            if (locationManager.isProviderEnabled(
                    LocationManager.NETWORK_PROVIDER)) {


                Location networkLocation =
                        locationManager.getLastKnownLocation(
                                LocationManager.NETWORK_PROVIDER);


                if (networkLocation != null) {

                    if (poslednjaLokacija == null
                            || networkLocation.getTime()
                            > poslednjaLokacija.getTime()) {

                        poslednjaLokacija =
                                networkLocation;
                    }
                }


                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        1000,
                        1,
                        locationListener);
            }


            // Ako imamo staru/poslednju poznatu lokaciju,
            // odmah je prikažemo.

            if (poslednjaLokacija != null) {

                prikaziLokaciju(poslednjaLokacija);

            } else {

                textViewLocation.setText(
                        "Lokacija: čekanje GPS signala...");
            }


        } catch (SecurityException e) {

            textViewLocation.setText(
                    "Greška pri pristupu lokaciji");
        }
    }


    // =====================================================
    // PRIKAZ LOKACIJE
    // =====================================================

    private void prikaziLokaciju(Location location) {

        String tekst =
                String.format(
                        Locale.getDefault(),
                        "Geografska širina: %.6f\nGeografska dužina: %.6f",
                        location.getLatitude(),
                        location.getLongitude());


        textViewLocation.setText(tekst);
    }


    // =====================================================
    // KAMERA
    // =====================================================

    private void otvoriKameru() {

        try {

            // =================================================
            // CACHE/IMAGES FOLDER
            // =================================================

            File imagesDirectory =
                    new File(
                            getCacheDir(),
                            "images");


            if (!imagesDirectory.exists()) {

                imagesDirectory.mkdirs();
            }


            // =================================================
            // NOVA FOTOGRAFIJA
            // =================================================

            File photoFile =
                    File.createTempFile(
                            "slika_",
                            ".jpg",
                            imagesDirectory);


            // =================================================
            // FILEPROVIDER URI
            // =================================================

            photoUri =
                    FileProvider.getUriForFile(
                            this,
                            getPackageName()
                                    + ".fileprovider",
                            photoFile);


            // =================================================
            // POKRETANJE KAMERE
            // =================================================

            cameraLauncher.launch(photoUri);


        } catch (IOException e) {

            Toast.makeText(
                    this,
                    "Greška pri kreiranju fotografije",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================================
    // RETROFIT
    // =====================================================

    private void dobaviUlogu(int roleId) {

        ApiService apiService =
                RetrofitClient
                        .getRetrofit()
                        .create(ApiService.class);


        Call<Role> call =
                apiService.getRole(roleId);


        call.enqueue(
                new Callback<Role>() {

                    @Override
                    public void onResponse(
                            Call<Role> call,
                            Response<Role> response) {


                        if (response.isSuccessful()
                                && response.body() != null) {


                            Role role =
                                    response.body();


                            // =================================
                            // ROLE -> JSON
                            // =================================

                            Gson gson =
                                    new Gson();


                            String roleJson =
                                    gson.toJson(role);


                            // =================================
                            // SHAREDPREFERENCES
                            // =================================

                            SharedPreferences preferences =
                                    getSharedPreferences(
                                            "KolokvijumPreferences",
                                            MODE_PRIVATE);


                            // Traženi ključ:
                            // "Uloga"

                            preferences
                                    .edit()
                                    .putString(
                                            "Uloga",
                                            roleJson)
                                    .apply();


                            // =================================
                            // TOAST
                            // =================================

                            Toast.makeText(
                                    MainActivity.this,
                                    "Sačuvana uloga: "
                                            + role.getId()
                                            + " - "
                                            + role.getName(),
                                    Toast.LENGTH_SHORT
                            ).show();


                        } else {

                            Toast.makeText(
                                    MainActivity.this,
                                    "Uloga nije pronađena",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }


                    @Override
                    public void onFailure(
                            Call<Role> call,
                            Throwable t) {


                        Toast.makeText(
                                MainActivity.this,
                                "Greška Retrofit: "
                                        + t.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }


    // =====================================================
    // SENZORI
    // =====================================================

    @Override
    public void onSensorChanged(
            SensorEvent event) {


        // =================================================
        // AKCELEROMETAR
        // =================================================

        if (event.sensor.getType()
                == Sensor.TYPE_ACCELEROMETER) {


            accX =
                    event.values[0];

            accY =
                    event.values[1];

            accZ =
                    event.values[2];
        }


        // =================================================
        // ŽIROSKOP
        // =================================================

        if (event.sensor.getType()
                == Sensor.TYPE_GYROSCOPE) {


            gyroX =
                    event.values[0];

            gyroY =
                    event.values[1];

            gyroZ =
                    event.values[2];
        }
    }


    @Override
    public void onAccuracyChanged(
            Sensor sensor,
            int accuracy) {

        // Nije potrebno za zadatak.
    }


    // =====================================================
    // ON RESUME
    // =====================================================

    @Override
    protected void onResume() {

        super.onResume();


        if (accelerometer != null) {

            sensorManager.registerListener(
                    this,
                    accelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }


        if (gyroscope != null) {

            sensorManager.registerListener(
                    this,
                    gyroscope,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
    }


    // =====================================================
    // ON PAUSE
    // =====================================================

    @Override
    protected void onPause() {

        super.onPause();

        sensorManager.unregisterListener(this);
    }


    // =====================================================
    // ON DESTROY
    // =====================================================

    @Override
    protected void onDestroy() {

        super.onDestroy();


        if (locationManager != null) {

            try {

                locationManager.removeUpdates(
                        locationListener);

            } catch (SecurityException ignored) {

            }
        }
    }
}